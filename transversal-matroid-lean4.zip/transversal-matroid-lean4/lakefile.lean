import Lake
open Lake DSL

package «women_theorems» where
  leanOptions := #[
    ⟨`autoImplicit, false⟩,
    ⟨`relaxedAutoImplicit, false⟩
  ]

/-! The project deliberately uses the checked local Mathlib copy supplied by
the research environment.  Its revision and Lean version are recorded in
`MATHLIB_ENVIRONMENT.md`. -/
require mathlib from "E:/Mathlib/mathlib4"

@[default_target]
lean_lib «Theorems» where
  srcDir := "formalizations/transversal-matroid/lean"
