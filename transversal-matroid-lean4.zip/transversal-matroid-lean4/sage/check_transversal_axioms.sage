"""Author: Carles Marín.

Program: executable finite sanity checks for the transversal-matroid specification.

Input: a finite list of finite sets representing a set-system presentation.
Output: the number and rank of partial transversals in the built-in example, and
        an exhaustive check of the three finite matroid independent-set axioms.
Verification status: auxiliary SageMath check only; it is not a formal proof.

This validates the exact finite predicate that the Lean development will
formalize and supplies small examples for regression tests and documentation.
"""

from itertools import combinations, permutations


def subsets(elements):
    elements = list(elements)
    return [frozenset(choice) for size in range(len(elements) + 1)
            for choice in combinations(elements, size)]


def partial_transversal(family, chosen):
    chosen = tuple(chosen)
    if len(chosen) > len(family):
        return False
    return any(
        all(element in family[index] for element, index in zip(chosen, indices))
        for indices in permutations(range(len(family)), len(chosen))
    )


def independent_sets(family):
    universe = set().union(*family)
    return {subset for subset in subsets(universe) if partial_transversal(family, subset)}


def verify_matroid_axioms(independent):
    assert frozenset() in independent
    assert all(smaller in independent
               for chosen in independent
               for smaller in subsets(chosen))
    assert all(
        any(chosen | {element} in independent for element in larger - chosen)
        for chosen in independent
        for larger in independent
        if len(chosen) < len(larger)
    )


family = [{"a", "b"}, {"b", "c"}, {"a", "c", "d"}]
independent = independent_sets(family)
verify_matroid_axioms(independent)

print("family:", family)
print("independent sets:", len(independent))
print("rank:", max(map(len, independent)))
print("all finite matroid axioms: verified")
