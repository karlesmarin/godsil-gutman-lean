# Registro de verificación

Fecha: 2026-07-21
Entorno: Lean `4.32.0`; Mathlib local `E:\Mathlib\mathlib4`, revisión
`84fdd0bfb8e85237f54b9617cca79c6198d40a75` (2026-07-15).

## Artefactos verificados

* `lean/Theorems/TransversalMatroid.lean` — la construcción (400 líneas, 15 teoremas, 4
  definiciones).
* `lean/Theorems/TransversalObstruction.lean` — la obstrucción canónica (245 líneas, 19
  teoremas, 5 definiciones e instancias).

El kernel de Lean aceptó todas las declaraciones sin `sorry`, `admit` ni `native_decide`.

### `TransversalMatroid.lean`

`compatible_iff`, `partialTransversal_empty`, `partialTransversal_subset`,
`partialTransversal_card_le_slots`, `partialTransversal_hall`, `hall_partialTransversal`,
`partialTransversal_iff_hall`, `not_partialTransversal_exists_hall_violation`,
`hall_violation_insert_mem`, `exists_tight_witness_of_not_insert`, `tight_union`,
`tight_biUnion`, `card_sdiff_le_of_tight_cover`, `partialTransversal_augmentation`,
`transversalMatroid_indep`, más las definiciones `Compatible`, `compatibleSlots`,
`IsPartialTransversal` y `transversalMatroid`.

### `TransversalObstruction.lean`

`slotsOf_union`, `slotsOf_inter_subset`, `slotsOf_mono`, `hall_card_le`,
`tight_union_and_inter`, `tight_union'`, `tight_inter`, `tight_empty`, `mem_tightSubsets`,
`maxTight_subset`, `subset_maxTight`, `maxTight_isTight`, `not_insert_of_tight_cover`,
`exists_tight_of_not_insert`, `not_insert_iff_exists_tight`,
`not_insert_iff_subset_maxTight`, `insert_iff_not_subset_maxTight`,
`transversalMatroid_ground`, `mem_closure_iff_subset_maxTight`, más las definiciones
`slotsOf`, `IsTight`, `tightSubsets`, `maxTight` y la instancia `decidableIsTight`.

## Comandos ejecutados

```powershell
lake build Theorems.TransversalMatroid
lake build Theorems.TransversalObstruction
lake env lean formalizations\transversal-matroid\lean\Theorems\AxiomReport.lean
python formalizations\transversal-matroid\sage\check_canonical_obstruction.sage
python formalizations\transversal-matroid\paper\figures\generate_obstruction_figures.py
```

`lake build` informó `Build completed successfully (1164 jobs)`.

## Informe de axiomas

`#print axioms` sobre los seis teoremas principales devuelve, en los seis casos,
únicamente `propext`, `Classical.choice` y `Quot.sound`:

```
'Theorems.TransversalMatroid.partialTransversal_augmentation'
'Theorems.TransversalMatroid.transversalMatroid_indep'
'Theorems.TransversalMatroid.tight_union_and_inter'
'Theorems.TransversalMatroid.maxTight_isTight'
'Theorems.TransversalMatroid.insert_iff_not_subset_maxTight'
'Theorems.TransversalMatroid.mem_closure_iff_subset_maxTight'
```

## Contrastes ejecutables (no son pruebas)

`check_canonical_obstruction.sage` recorre la presentación del artículo de forma
exhaustiva:

* 56 transversales parciales; 180 decisiones de inserción, todas coincidentes con
  `maxTight`.
* Fórmula de defecto de Ore `r(X) = min_S (|X\S| + |N(S)|)`: verificada en los 64
  subconjuntos del conjunto base. **Esta fórmula NO está formalizada**; el artículo la
  declara trabajo futuro, no resultado.

## Alcance y límite

Verificado el teorema del matroide transversal para una presentación finita
`A : Fin t → Finset α`: los transversales parciales son los conjuntos independientes de un
matroide sobre `α`, y los elementos de `α` que no aparecen en `A` quedan como lazos. Sobre
esa base, el retículo de conjuntos tight, el máximo `maxTight A I`, el criterio de inserción
y su lectura como operador de clausura de Mathlib.

No cubre familias indexadas infinitas, no implementa ningún algoritmo, y no afirma novedad
bibliográfica salvo en los términos fechados y falsables de la sección de prioridad del
artículo.
