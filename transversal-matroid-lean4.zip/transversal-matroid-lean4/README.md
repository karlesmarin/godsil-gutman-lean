# The Set That Says No — transversal matroids in Lean 4

Reproduction bundle for *The Set That Says No: transversal matroids in Lean 4, a tight-set proof
of augmentation, and the canonical obstruction it makes possible* (Carles Marín, July 2026).

Everything the paper asserts about the machine-checked content is reproducible from this bundle.

## What is in here

```
lean/Theorems/TransversalMatroid.lean      the construction        400 lines, 15 thm, 4 def
lean/Theorems/TransversalObstruction.lean  the canonical obstruction 245 lines, 19 thm, 5 def
lean/Theorems/AxiomReport.lean             #print axioms on the six headline theorems
sage/check_canonical_obstruction.sage           exhaustive cross-check of the running example
sage/check_transversal_axioms.sage              independent check of the three matroid axioms
paper/…-lean4.tex / .pdf                        the paper (English)
paper/…-lean4-es.tex / .pdf                     the paper (Spanish edition)
paper/figures/generate_obstruction_figures.py   the figure generator
paper/figures/fig_*_3d.png                      the four data figures
lakefile.lean, lean-toolchain                   the build configuration
MATHLIB_ENVIRONMENT.md, VERIFICATION.md         environment and verification record
```

## Environment

* Lean 4, toolchain `leanprover/lean4:v4.32.0`.
* Mathlib at revision `84fdd0bfb8e85237f54b9617cca79c6198d40a75` (2026-07-15),
  <https://github.com/leanprover-community/mathlib4>.

`lakefile.lean` points at a **local** compiled Mathlib. To build elsewhere, edit the
`require mathlib from "…"` line to point at your own compiled Mathlib at that toolchain.

## Reproducing the proofs

```
lake build Theorems.TransversalMatroid            # the construction
lake build Theorems.TransversalObstruction        # the canonical obstruction
lake env lean lean/Theorems/AxiomReport.lean      # the trust report
```

Expected trust report — one line per headline theorem, and nothing beyond the three standard
axioms:

```
'…partialTransversal_augmentation'      depends on axioms: [propext, Classical.choice, Quot.sound]
'…transversalMatroid_indep'             depends on axioms: [propext, Classical.choice, Quot.sound]
'…tight_union_and_inter'                depends on axioms: [propext, Classical.choice, Quot.sound]
'…maxTight_isTight'                     depends on axioms: [propext, Classical.choice, Quot.sound]
'…insert_iff_not_subset_maxTight'       depends on axioms: [propext, Classical.choice, Quot.sound]
'…mem_closure_iff_subset_maxTight'      depends on axioms: [propext, Classical.choice, Quot.sound]
```

Both Lean files are `sorry`-free; neither uses `admit` or `native_decide`.

## Reproducing the cross-checks

```
python sage/check_canonical_obstruction.sage
```

Runs under plain `python3` as well as `sage` — it uses no Sage-specific call. Expected tail:

```
partial transversals: 56; insertion decisions checked: 180; all agree with maxTight.
Ore defect formula r(X) = min_S (|X\S| + |N(S)|): verified on all 64 subsets of the ground set.
```

The second line is the one formula in the paper that is **checked but not formalized**; the paper
says so, and lists it as future work rather than as a result.

`sage/check_transversal_axioms.sage` is an older, independent check of the three finite matroid
independent-set axioms; it uses a different, smaller presentation than the paper's running example,
and is kept because it exercises the axioms directly.

## Reproducing the figures

```
python paper/figures/generate_obstruction_figures.py
```

The generator recomputes every plotted quantity from the presentation by exhaustive enumeration and
**asserts it against the theorem before drawing**, so a figure cannot drift away from the
mathematics it illustrates. Requires `matplotlib` and `pillow`. Note: the raster output is stable
run to run, but the very first run on a fresh machine may differ by a few bytes while matplotlib
builds its font cache; the plotted data is unaffected.

## Scope, honestly

* Finite presentations only: `A : Fin t → Finset α`, each `A i` finite. The infinite version
  (Mirsky–Perfect) is **not** covered.
* No algorithmic claim. `maxTight` is defined by a powerset filter and is not efficient; the
  theorem certifies the characterisation, not a procedure.
* The mathematics is classical (Edmonds–Fulkerson; Mirsky–Perfect; Ore; Dulmage–Mendelsohn). What
  is offered is the formalisation, its layered architecture, and the packaging of the obstruction
  as a canonical object.
* Priority claims, what was searched to support them, on what date, and what would refute them are
  stated in the paper's own section on priority. They are audit statuses, not proofs of absence.

## Author

Carles Marín, independent researcher — <karlesmarin@gmail.com>.
Formalized with the assistance of an AI system (Claude, Anthropic); every claim, scope statement
and limitation is the author's responsibility, and the Lean kernel is what certifies the proofs.

Licence: CC BY 4.0.
