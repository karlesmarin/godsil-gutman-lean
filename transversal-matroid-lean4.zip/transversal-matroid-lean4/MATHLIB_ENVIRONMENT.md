# Entorno Lean / Mathlib

El desarrollo se verifica localmente contra `E:\Mathlib\mathlib4`, la copia de
Mathlib proporcionada para este proyecto. En la comprobación inicial del 20 de
julio de 2026 se constató que contiene los artefactos compilados de Mathlib y
que declara el toolchain `leanprover/lean4:v4.32.0`.

Esta elección evita que una formalización dependa de la descarga de cachés
remotas. Para reproducirla en otra máquina, sustituir la ruta local de
`lakefile.lean` por una copia compilada de Mathlib con el mismo toolchain, y
registrar aquí la revisión exacta usada.
